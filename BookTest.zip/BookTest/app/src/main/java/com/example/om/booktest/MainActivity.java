package com.example.om.booktest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {



    //

    ListView listview;
    ArrayAdapter<String>adapter;



    FirebaseDatabase database;
    DatabaseReference ref;

    ArrayList<String>list;

    ProgressBar  progressBar;

    User user;
    SearchView searchView;
    private Spinner spinner1;
    private Spinner spinner2;

    private String Stream1;

    String Stream[] = {"  ", " B.COM FINANCIAL MARKETS", "B.COM", "B.COM (ACCOUNTING AND FINANCE)",
            "B.MM", "B.MS","B.SC.COMPUTER SCIENCE"};
    String Year[]={"   ","FirstYear","SecondYear","ThirdYear"};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        listview=findViewById(R.id.listview);
        searchView=findViewById(R.id.searchview);


        database=FirebaseDatabase.getInstance();
        progressBar=findViewById(R.id.progressBar2);

        user=new User();
        ref=database.getReference("Data");
        list=new ArrayList<>();
        adapter=new ArrayAdapter<String>(this,R.layout.user_info,R.id.description,list);
        spinner1 = (Spinner)findViewById(R.id.spinner);
        spinner2 = (Spinner)findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Stream);
        spinner1.setAdapter(adapter1);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Year);
        spinner2.setAdapter(adapter2);








        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String text) {
                adapter.getFilter().filter(Stream1);
                adapter.getFilter().filter(text);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String text) {
                adapter.getFilter().filter(Stream1);
                adapter.getFilter().filter(text);
                return false;
            }
        });








        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {


            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long id) {


                if (i==0)
                {
                    onStart();


                }
                if (i==1)

                {


                     Stream1="B.COM FINANCIAL MARKETS";
                   adapter.getFilter().filter(Stream1);







                }

                if (i==2)
                {
                    Stream1="B.COM";
                    adapter.getFilter().filter(Stream1);





                }

                if (i==3)
                {
                    Stream1="B.MM";
                    adapter.getFilter().filter(Stream1);

                }
                if (i==4)
                {
                    Stream1="B.MS";
                    adapter.getFilter().filter(Stream1);

                }
                if (i==5)
                {

                    Stream1="B.SC.COMPUTER SCIENCE";
                    adapter.getFilter().filter(Stream1);

                }




            }



            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        });






    }

    public void search(String stream,String year){
        FirebaseDatabase.getInstance().getReference().child("Data").equalTo("stream").startAt(Stream1).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                String id =dataSnapshot.getKey();
                if (dataSnapshot.child("stream").exists())
                {
                    if (dataSnapshot.child("stream").getValue(String.class).equals(Stream1))
                    {
                        listview.setAdapter(adapter);
                    }
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });



    }

    @Override
    protected void onResume() {
        super.onResume();



    }

    @Override
    protected void onRestart() {
        super.onRestart();
        progressBar.setVisibility(View.GONE);

    }

    @Override
    protected void onStart() {
        super.onStart();
        progressBar.setVisibility(View.VISIBLE);

        ref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    user = ds.getValue(User.class);
                    list.add(user.getDescription().toString() + "\n " +
                            "  " + user.getStream().toString() + "  " +
                            " " + user.getTitle().toString() + "  " + user.getYear().toString());
                }
                progressBar.setVisibility(View.GONE);
                listview.setAdapter(adapter);


            }


            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });

    }




}
