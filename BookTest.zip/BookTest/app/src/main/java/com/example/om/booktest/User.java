package com.example.om.booktest;

public class User {
    private String description;
    private String stream;
    private String title;
    private String year;

    public User() {
    }

    public User(String description, String stream, String title, String year) {
        this.description = description;
        this.stream = stream;
        this.title = title;
        this.year = year;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStream() {
        return stream;
    }

    public void setStream(String stream) {
        this.stream = stream;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}
